const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const { Pool } = require('pg');

const app = express();

const PORT = Number(process.env.PORT || 3000);

const JWT_SECRET =
  process.env.JWT_SECRET ||
  'craftverse-development-secret-change-me';

const WEB_DIR = path.join(__dirname, '..', 'web');

/* =========================================================
   DATABASE
   ========================================================= */

if (!process.env.DATABASE_URL) {
  console.warn(
    'WARNING: DATABASE_URL is not configured.'
  );
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

/* =========================================================
   MIDDLEWARE
   ========================================================= */

app.use(
  express.json({
    limit: '2mb'
  })
);

// Parsed once at startup instead of on every request. A Set also turns the
// allow-list check from an O(C) array scan into an O(1) lookup, where C is
// the number of configured origins.
const ALLOWED_ORIGINS = new Set(
  (process.env.CORS_ORIGINS || '')
    .split(',')
    .map(x => x.trim())
    .filter(Boolean)
);

app.use(
  cors({
    origin: (origin, cb) => {
      // Allow requests without an Origin header
      // and Chrome extension requests.
      if (
        !origin ||
        ALLOWED_ORIGINS.size === 0 ||
        ALLOWED_ORIGINS.has(origin) ||
        origin.startsWith('chrome-extension://')
      ) {
        return cb(null, true);
      }

      cb(new Error('CORS origin not allowed'));
    }
  })
);

/* =========================================================
   DATABASE INITIALIZATION
   ========================================================= */

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS profiles (
      user_id TEXT PRIMARY KEY
        REFERENCES users(id)
        ON DELETE CASCADE,

      profile JSONB NOT NULL DEFAULT '{}'::jsonb,

      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS histories (
      user_id TEXT PRIMARY KEY
        REFERENCES users(id)
        ON DELETE CASCADE,

      history JSONB NOT NULL DEFAULT '[]'::jsonb,

      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,

      user_id TEXT NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

      url TEXT NOT NULL,

      profile JSONB NOT NULL DEFAULT '{}'::jsonb,

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

      expires_at TIMESTAMPTZ NOT NULL,

      consumed BOOLEAN NOT NULL DEFAULT FALSE
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS sessions_user_id_idx
    ON sessions(user_id)
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS sessions_expires_at_idx
    ON sessions(expires_at)
  `);

  // Composite index matching the exact filter used by the pending-session
  // lookup (user_id + consumed + expires_at together), so Postgres can
  // satisfy it with a single index range scan instead of combining the two
  // single-column indexes above.
  await pool.query(`
    CREATE INDEX IF NOT EXISTS sessions_active_lookup_idx
    ON sessions(user_id, consumed, expires_at)
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS history_items (
      id BIGSERIAL PRIMARY KEY,

      user_id TEXT NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

      url TEXT NOT NULL,
      fields INTEGER NOT NULL DEFAULT 0,
      match TEXT NOT NULL DEFAULT '—',

      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS history_items_user_created_idx
    ON history_items(user_id, created_at DESC)
  `);

  // Best-effort, one-time backfill from the legacy JSONB blob table
  // (`histories`) into the new row-per-entry `history_items` table. Wrapped
  // so a malformed legacy row can never block server startup: worst case,
  // a user's old history simply isn't migrated and they start fresh.
  try {
    await pool.query(`
      INSERT INTO history_items (user_id, url, fields, match, created_at)
      SELECT
        h.user_id,
        COALESCE(NULLIF(item->>'url', ''), 'Form'),
        COALESCE((item->>'fields')::int, 0),
        COALESCE(NULLIF(item->>'match', ''), '—'),
        COALESCE((item->>'createdAt')::timestamptz, NOW())
      FROM histories h,
           LATERAL jsonb_array_elements(h.history) AS item
      WHERE NOT EXISTS (
        SELECT 1 FROM history_items hi WHERE hi.user_id = h.user_id
      )
    `);
  } catch (error) {
    console.warn('Legacy history migration skipped:', error.message);
  }

  console.log('Database initialized successfully.');
}

/* =========================================================
   BACKGROUND SESSION SWEEP

   Per-request cleanup in POST /api/autofill/session only ever removes rows
   for the requesting user. A user who creates one session and never
   returns leaves that row behind forever, so table size grows with the
   total number of sessions ever created instead of the number of sessions
   actually pending. This periodic sweep deletes every expired/consumed
   session for every user, bounding storage to O(live sessions) rather than
   O(sessions created over the service's lifetime).
   ========================================================= */

const SESSION_SWEEP_INTERVAL_MS = 5 * 60 * 1000;

async function sweepExpiredSessions() {
  try {
    const result = await pool.query(
      `DELETE FROM sessions WHERE expires_at <= NOW() OR consumed = true`
    );
    if (result.rowCount) {
      console.log(`Session sweep removed ${result.rowCount} row(s).`);
    }
  } catch (error) {
    console.error('Session sweep error:', error);
  }
}

/* =========================================================
   HELPERS
   ========================================================= */

function safeUser(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    createdAt: user.createdAt
  };
}

function issueToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      email: user.email
    },
    JWT_SECRET,
    {
      expiresIn: '30d'
    }
  );
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* =========================================================
   AUTH MIDDLEWARE
   ========================================================= */

async function auth(req, res, next) {
  const header = req.headers.authorization || '';

  const token = header.startsWith('Bearer ')
    ? header.slice(7)
    : '';

  if (!token) {
    return res.status(401).json({
      error: 'Authentication required'
    });
  }

  try {
    req.auth = jwt.verify(token, JWT_SECRET);

    const result = await pool.query(
      `
      SELECT id
      FROM users
      WHERE id = $1
      `,
      [req.auth.sub]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        error: 'Account not found'
      });
    }

    next();

  } catch (error) {
    console.error('Authentication error:', error);

    return res.status(401).json({
      error: 'Invalid or expired session'
    });
  }
}

/* =========================================================
   HEALTH
   ========================================================= */

app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');

    res.json({
      ok: true,
      service: 'formly',
      version: '4.0.0',
      database: 'connected'
    });

  } catch (error) {
    console.error('Health check error:', error);

    res.status(500).json({
      ok: false,
      service: 'formly',
      database: 'disconnected'
    });
  }
});

/* =========================================================
   REGISTER
   ========================================================= */

app.post('/api/auth/register', async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '')
      .trim()
      .toLowerCase();

    const password = String(req.body.password || '');

    if (name.length < 2) {
      return res.status(400).json({
        error: 'Enter your name'
      });
    }

    if (!validateEmail(email)) {
      return res.status(400).json({
        error: 'Enter a valid email'
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        error: 'Password must be at least 8 characters'
      });
    }

    const existing = await pool.query(
      `
      SELECT id
      FROM users
      WHERE email = $1
      `,
      [email]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({
        error: 'An account with this email already exists'
      });
    }

    const id = crypto.randomUUID();

    const passwordHash = await bcrypt.hash(
      password,
      12
    );

    const createdAt = new Date();

    await pool.query(
      `
      INSERT INTO users
      (
        id,
        name,
        email,
        password_hash,
        created_at
      )
      VALUES
      ($1, $2, $3, $4, $5)
      `,
      [
        id,
        name,
        email,
        passwordHash,
        createdAt
      ]
    );

    /*
      Create an empty profile record for the new user. History no longer
      needs a pre-created row: history_items is a normal row-per-entry
      table, so "no rows for this user_id" already means "no history".
    */

    await pool.query(
      `
      INSERT INTO profiles
      (
        user_id,
        profile
      )
      VALUES
      ($1, $2)
      `,
      [
        id,
        JSON.stringify({})
      ]
    );

    const user = {
      id,
      name,
      email,
      passwordHash,
      createdAt
    };

    return res.status(201).json({
      token: issueToken(user),
      user: safeUser(user)
    });

  } catch (error) {
    console.error(
      'Registration error:',
      error
    );

    res.status(500).json({
      error: 'Failed to create account'
    });
  }
});

/* =========================================================
   LOGIN
   ========================================================= */

app.post('/api/auth/login', async (req, res) => {
  try {
    const email = String(req.body.email || '')
      .trim()
      .toLowerCase();

    const password = String(
      req.body.password || ''
    );

    const result = await pool.query(
      `
      SELECT
        id,
        name,
        email,
        password_hash,
        created_at
      FROM users
      WHERE email = $1
      `,
      [email]
    );

    const row = result.rows[0];

    if (!row) {
      return res.status(401).json({
        error: 'Incorrect email or password'
      });
    }

    const valid = await bcrypt.compare(
      password,
      row.password_hash
    );

    if (!valid) {
      return res.status(401).json({
        error: 'Incorrect email or password'
      });
    }

    const user = {
      id: row.id,
      name: row.name,
      email: row.email,
      passwordHash: row.password_hash,
      createdAt: row.created_at
    };

    res.json({
      token: issueToken(user),
      user: safeUser(user)
    });

  } catch (error) {
    console.error(
      'Login error:',
      error
    );

    res.status(500).json({
      error: 'Failed to login'
    });
  }
});

/* =========================================================
   CURRENT USER
   ========================================================= */

app.get(
  '/api/auth/me',
  auth,
  async (req, res) => {
    try {
      const result = await pool.query(
        `
        SELECT
          id,
          name,
          email,
          created_at
        FROM users
        WHERE id = $1
        `,
        [req.auth.sub]
      );

      const row = result.rows[0];

      if (!row) {
        return res.status(404).json({
          error: 'Account not found'
        });
      }

      res.json({
        user: {
          id: row.id,
          name: row.name,
          email: row.email,
          createdAt: row.created_at
        }
      });

    } catch (error) {
      console.error(
        'Auth/me error:',
        error
      );

      res.status(500).json({
        error: 'Failed to load account'
      });
    }
  }
);

/* =========================================================
   PROFILE - GET
   ========================================================= */

app.get(
  '/api/profile',
  auth,
  async (req, res) => {
    try {
      const result = await pool.query(
        `
        SELECT profile
        FROM profiles
        WHERE user_id = $1
        `,
        [req.auth.sub]
      );

      res.json({
        profile:
          result.rows[0]?.profile || {}
      });

    } catch (error) {
      console.error(
        'Profile load error:',
        error
      );

      res.status(500).json({
        error: 'Failed to load profile'
      });
    }
  }
);

/* =========================================================
   PROFILE - SAVE
   ========================================================= */

app.post(
  '/api/profile',
  auth,
  async (req, res) => {
    try {
      const profile =
        req.body &&
        typeof req.body === 'object'
          ? req.body
          : {};

      await pool.query(
        `
        INSERT INTO profiles
        (
          user_id,
          profile,
          updated_at
        )
        VALUES
        ($1, $2, NOW())

        ON CONFLICT (user_id)
        DO UPDATE SET
          profile = EXCLUDED.profile,
          updated_at = NOW()
        `,
        [
          req.auth.sub,
          JSON.stringify(profile)
        ]
      );

      res.json({
        ok: true,
        profile
      });

    } catch (error) {
      console.error(
        'Profile save error:',
        error
      );

      res.status(500).json({
        error: 'Failed to save profile'
      });
    }
  }
);

/* =========================================================
   HISTORY HELPERS

   Shared by POST /api/history and the autofill-session consume handler,
   which both need to append one entry and keep only the 100 most recent
   per user.
   ========================================================= */

async function insertHistoryItem(userId, { url, fields, match, createdAt } = {}) {
  const created = createdAt ? new Date(createdAt) : new Date();
  const fieldCount = Number.isFinite(Number(fields)) ? Number(fields) : 0;

  const inserted = await pool.query(
    `
    INSERT INTO history_items
    (
      user_id,
      url,
      fields,
      match,
      created_at
    )
    VALUES
    ($1, $2, $3, $4, $5)
    RETURNING
      url,
      fields,
      match,
      created_at AS "createdAt"
    `,
    [
      userId,
      String(url || 'Form'),
      fieldCount,
      String(match || '—'),
      created
    ]
  );

  // Trim to the 100 most recent rows for this user. A single indexed
  // window-function delete (O(log n) via history_items_user_created_idx)
  // instead of the old pattern of reading the full history array into
  // Node, unshifting, slicing, and rewriting the entire JSONB blob on
  // every append.
  await pool.query(
    `
    DELETE FROM history_items hi
    USING (
      SELECT id, ROW_NUMBER() OVER (ORDER BY created_at DESC) AS rn
      FROM history_items
      WHERE user_id = $1
    ) ranked
    WHERE hi.id = ranked.id
      AND ranked.rn > 100
    `,
    [userId]
  );

  return inserted.rows[0];
}

/* =========================================================
   HISTORY - GET
   ========================================================= */

app.get(
  '/api/history',
  auth,
  async (req, res) => {
    try {
      // Index range scan on history_items_user_created_idx: O(log n + 100),
      // and only the 100 rows actually needed ever leave the database.
      // The old version read the *entire* JSONB blob (already capped at
      // 100, but still fully deserialized) on every request.
      const result = await pool.query(
        `
        SELECT
          url,
          fields,
          match,
          created_at AS "createdAt"
        FROM history_items
        WHERE user_id = $1
        ORDER BY created_at DESC
        LIMIT 100
        `,
        [req.auth.sub]
      );

      res.json({
        history: result.rows
      });

    } catch (error) {
      console.error(
        'History load error:',
        error
      );

      res.status(500).json({
        error: 'Failed to load history'
      });
    }
  }
);

/* =========================================================
   HISTORY - SAVE
   ========================================================= */

app.post(
  '/api/history',
  auth,
  async (req, res) => {
    try {
      const item = await insertHistoryItem(
        req.auth.sub,
        req.body || {}
      );

      res.json({
        ok: true,
        item
      });

    } catch (error) {
      console.error(
        'History save error:',
        error
      );

      res.status(500).json({
        error: 'Failed to save history'
      });
    }
  }
);

/* =========================================================
   AUTOFILL SESSION - CREATE
   ========================================================= */

app.post(
  '/api/autofill/session',
  auth,
  async (req, res) => {
    try {
      const url = String(
        req.body.url || ''
      ).trim();

      if (!url) {
        return res.status(400).json({
          error: 'Form URL is required'
        });
      }

      let parsed;

      try {
        parsed = new URL(url);
      } catch {
        return res.status(400).json({
          error: 'Invalid form URL'
        });
      }

      let profile = req.body.profile;

      /*
        If the frontend doesn't send the profile,
        load it from the database.
      */

      if (
        !profile ||
        typeof profile !== 'object'
      ) {
        const result = await pool.query(
          `
          SELECT profile
          FROM profiles
          WHERE user_id = $1
          `,
          [req.auth.sub]
        );

        profile =
          result.rows[0]?.profile || {};
      }

      const id = crypto.randomUUID();

      const createdAt = Date.now();

      const expiresAt =
        createdAt + 5 * 60 * 1000;

      /*
        Remove old/expired sessions
        for this user.
      */

      await pool.query(
        `
        DELETE FROM sessions
        WHERE user_id = $1
          AND (
            expires_at <= NOW()
            OR consumed = true
          )
        `,
        [req.auth.sub]
      );

      await pool.query(
        `
        INSERT INTO sessions
        (
          id,
          user_id,
          url,
          profile,
          created_at,
          expires_at,
          consumed
        )
        VALUES
        ($1, $2, $3, $4, $5, $6, false)
        `,
        [
          id,
          req.auth.sub,
          parsed.toString(),
          JSON.stringify(profile),
          new Date(createdAt),
          new Date(expiresAt)
        ]
      );

      res.status(201).json({
        ok: true,
        url: parsed.toString(),
        sessionId: id,
        expiresAt
      });

    } catch (error) {
      console.error(
        'Autofill session error:',
        error
      );

      res.status(500).json({
        error: 'Failed to create autofill session'
      });
    }
  }
);

/* =========================================================
   AUTOFILL SESSION - PENDING
   ========================================================= */

app.get(
  '/api/autofill/pending',
  auth,
  async (req, res) => {
    try {
      const requested = String(
        req.query.url || ''
      );

      let query = `
        SELECT
          id,
          user_id,
          url,
          profile,
          created_at,
          expires_at,
          consumed
        FROM sessions
        WHERE user_id = $1
          AND consumed = false
          AND expires_at > NOW()
      `;

      const params = [
        req.auth.sub
      ];

      if (requested) {
        query += `
          AND url = $2
        `;

        params.push(requested);
      }

      query += `
        ORDER BY created_at DESC
        LIMIT 1
      `;

      const result =
        await pool.query(
          query,
          params
        );

      res.json({
        session:
          result.rows[0] || null
      });

    } catch (error) {
      console.error(
        'Pending session error:',
        error
      );

      res.status(500).json({
        error: 'Failed to load autofill session'
      });
    }
  }
);

/* =========================================================
   AUTOFILL SESSION - CONSUME
   ========================================================= */

app.post(
  '/api/autofill/consume',
  auth,
  async (req, res) => {
    try {
      const id = String(
        req.body.sessionId || ''
      );

      const result = await pool.query(
        `
        SELECT
          id,
          user_id,
          url,
          profile
        FROM sessions
        WHERE id = $1
          AND user_id = $2
          AND consumed = false
        `,
        [
          id,
          req.auth.sub
        ]
      );

      const session =
        result.rows[0];

      if (!session) {
        return res.status(404).json({
          error: 'Autofill session not found'
        });
      }

      await pool.query(
        `
        UPDATE sessions
        SET consumed = true
        WHERE id = $1
        `,
        [id]
      );

      const profile =
        session.profile || {};

      await insertHistoryItem(req.auth.sub, {
        url: session.url,

        fields: Object.keys(profile)
          .filter(
            key =>
              String(
                profile[key] || ''
              ).trim()
          )
          .length,

        match: '—',

        createdAt:
          new Date().toISOString()
      });

      res.json({
        ok: true
      });

    } catch (error) {
      console.error(
        'Consume session error:',
        error
      );

      res.status(500).json({
        error: 'Failed to consume autofill session'
      });
    }
  }
);

/* =========================================================
   WEBSITE
   ========================================================= */

app.use(
  express.static(WEB_DIR)
);

app.get(
  '*',
  (req, res) => {
    res.sendFile(
      path.join(
        WEB_DIR,
        'index.html'
      )
    );
  }
);

/* =========================================================
   START SERVER
   ========================================================= */

async function startServer() {
  try {
    await initializeDatabase();

    await sweepExpiredSessions();
    setInterval(sweepExpiredSessions, SESSION_SWEEP_INTERVAL_MS);

    app.listen(
      PORT,
      () => {
        console.log(
          `Formly running at http://localhost:${PORT}`
        );
      }
    );

  } catch (error) {
    console.error(
      'Failed to initialize server:',
      error
    );

    process.exit(1);
  }
}

startServer();